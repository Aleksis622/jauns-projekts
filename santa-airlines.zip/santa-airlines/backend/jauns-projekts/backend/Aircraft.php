<?php
class Aircraft {


 public function __construct(
     public $razotajs,
     public $model,
     public $seats,
     public $speed ) {

 

 }
 

}